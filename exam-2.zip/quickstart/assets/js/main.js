(function ($) {
    "use strict";

    jQuery(document).ready(function ($) {


        $(".embed-responsive iframe").addClass("embed-responsive-item");
        $(".carousel-inner .item:first-child").addClass("active");

        $('[data-toggle="tooltip"]').tooltip();



        $(".testimonial_carosel").owlCarousel({
            items: 1,
            loop: true,
            autoplay: true,
        });
        $('.video_frame').magnificPopup({
            type: 'video'
            // other options
        });
        $('#menu').slicknav();
    });


    jQuery(window).load(function () {


    });


}(jQuery));